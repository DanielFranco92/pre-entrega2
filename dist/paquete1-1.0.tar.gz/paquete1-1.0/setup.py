from setuptools import setup

setup(
    name="paquete1",
    version="1.0",
    description="Estamos haciendo el primer paquete distribuido",
    author="Daniel Franco",
    author_email="dfranco@agea.com.ar",
    packages=["paquete1"]
)